class ImageAssets {
  static const String splashScreen= 'assets/images/nahid_hasan.jpg';
  static const String iconsPng= 'assets/icons/arrow.png';
}