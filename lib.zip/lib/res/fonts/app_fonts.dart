class AppFonts{
  static const String schylerRegular='Schyler-Regular';
}