class AppUrl{
  static const String baseUrl='https://reqres.in';

  static const String loginUrl='$baseUrl/api/login';

  static const String userListApi='https://webhook.site/e306b6c5-7cd7-4d01-b896-aee44f1ae684';
}